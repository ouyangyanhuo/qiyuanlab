<!DOCTYPE HTML>
<!--HEADER_1-->
<?php include("header_1.php");?>
    <title>源·表情 - 云表情引用</title>
    <meta name="description" content="源·表情 - 云表情引用"/>
    <meta name="keywords" content="源·表情,云表情引用"/>
<!--HEADER_2-->
<?php include("header_2.php");?>
<h1 class="web-title">源·表情 <small>云表情引用</small></h1>
<nav class="navbar navbar-default">
<div class="container-fluid">
	<div class="navbar-header" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
			<span class="sr-only">源·表情 云表情引用</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand">源·表情 云表情引用</a>
	</div>
<!--HEADER_3-->
<?php include("header_3.php");?>
</div>
</nav>
</div>
<div class="container">
<div class="row">
	<!--表情1-->
    <div class="col-sm-6 col-md-4 col-lg-3 tool-item cx">
        <div class="thumbnail example">
            <img class="lazy" src="https://s2.ax1x.com/2020/01/04/l0aSwF.jpg" width="300" height="150">
        </div>
    </div>
</div>
</div>
<!--FOOTER-->
<?php include("footer.php");?>
</body> 
</html> 