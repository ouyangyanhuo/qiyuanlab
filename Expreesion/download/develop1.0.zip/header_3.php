	<div id="navbar" class="navbar-collapse collapse">	  
		<ul class="nav navbar-nav">
			<li><a href="./"><span style="color: red;">首页</span></a></li>
			<li><a href="./Mode.php">引用方式</a></li>
			<li><a href="./Announcement.php">最新公告</a></li>
			<li><a href="/App/Pay">捐赠</a></li>
			<li><a href="http://www.kpan.me" target="_blank">实验室</a></li>
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li><a href="https://support.qq.com/product/96005" target="_blank">留言反馈</a></li>
		</ul>
	</div>